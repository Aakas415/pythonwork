# Python-Practicals-by-AB
These practicals are for the student or python beginner specially for co-6 python subject
